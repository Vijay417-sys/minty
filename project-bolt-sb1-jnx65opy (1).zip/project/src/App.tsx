import React, { useState } from 'react';
import { IndianRupee, PiggyBank, TrendingUp, School, Calculator, ArrowRight } from 'lucide-react';

function App() {
  const [selectedTopic, setSelectedTopic] = useState('');
  const [language, setLanguage] = useState('english');

  const topics = {
    savings: {
      english: {
        title: 'Basic Savings',
        description: 'Learn how to save money and build emergency funds',
        tips: [
          'Start with saving ₹100 per week',
          'Keep money in a bank instead of at home',
          'Save first, spend what remains'
        ]
      },
      hindi: {
        title: 'बचत की मूल बातें',
        description: 'पैसे कैसे बचाएं और आपातकालीन फंड कैसे बनाएं',
        tips: [
          'हर हफ्ते ₹100 की बचत से शुरुआत करें',
          'पैसे को घर की बजाय बैंक में रखें',
          'पहले बचत करें, बाकी खर्च करें'
        ]
      }
    },
    investment: {
      english: {
        title: 'Smart Investments',
        description: 'Simple ways to grow your money safely',
        tips: [
          'Start with Fixed Deposits',
          'Consider Post Office savings',
          'Learn about government schemes'
        ]
      },
      hindi: {
        title: 'स्मार्ट निवेश',
        description: 'अपने पैसे को सुरक्षित तरीके से बढ़ाने के सरल तरीके',
        tips: [
          'फिक्स्ड डिपॉजिट से शुरुआत करें',
          'पोस्ट ऑफिस की बचत योजनाओं पर विचार करें',
          'सरकारी योजनाओं के बारे में जानें'
        ]
      }
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white">
      <nav className="bg-white shadow-lg">
        <div className="max-w-7xl mx-auto px-4 py-3 flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <IndianRupee className="h-6 w-6 text-blue-600" />
            <span className="text-xl font-bold text-gray-800">FinanceGuru</span>
          </div>
          <select
            value={language}
            onChange={(e) => setLanguage(e.target.value)}
            className="border rounded-md px-2 py-1"
          >
            <option value="english">English</option>
            <option value="hindi">हिंदी</option>
          </select>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto px-4 py-8">
        {!selectedTopic ? (
          <>
            <div className="text-center mb-12">
              <h1 className="text-4xl font-bold text-gray-900 mb-4">
                {language === 'english' ? 'Your Personal Finance Guide' : 'आपका व्यक्तिगत वित्तीय मार्गदर्शक'}
              </h1>
              <p className="text-xl text-gray-600">
                {language === 'english' 
                  ? 'Simple financial advice for a better future' 
                  : 'बेहतर भविष्य के लिए सरल वित्तीय सलाह'}
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[
                { icon: PiggyBank, topic: 'savings', color: 'bg-green-100' },
                { icon: TrendingUp, topic: 'investment', color: 'bg-blue-100' },
                { icon: School, topic: 'education', color: 'bg-purple-100' },
                { icon: Calculator, topic: 'calculator', color: 'bg-yellow-100' }
              ].map(({ icon: Icon, topic, color }) => (
                <button
                  key={topic}
                  onClick={() => setSelectedTopic(topic)}
                  className={`${color} p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow duration-200`}
                >
                  <Icon className="h-12 w-12 mx-auto mb-4" />
                  <h2 className="text-xl font-semibold text-gray-800 mb-2">
                    {topics[topic]?.[language]?.title || (language === 'english' ? topic : topic)}
                  </h2>
                  <ArrowRight className="h-5 w-5 mx-auto mt-4 text-gray-600" />
                </button>
              ))}
            </div>
          </>
        ) : (
          <div className="max-w-2xl mx-auto bg-white rounded-lg shadow-lg p-8">
            <button
              onClick={() => setSelectedTopic('')}
              className="text-blue-600 mb-6 flex items-center"
            >
              <ArrowRight className="h-4 w-4 mr-2 transform rotate-180" />
              {language === 'english' ? 'Back to topics' : 'विषयों पर वापस जाएं'}
            </button>

            {topics[selectedTopic] && (
              <>
                <h2 className="text-3xl font-bold mb-4">{topics[selectedTopic][language].title}</h2>
                <p className="text-gray-600 mb-6">{topics[selectedTopic][language].description}</p>
                <ul className="space-y-4">
                  {topics[selectedTopic][language].tips.map((tip, index) => (
                    <li key={index} className="flex items-start">
                      <span className="flex-shrink-0 h-6 w-6 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center mr-3">
                        {index + 1}
                      </span>
                      {tip}
                    </li>
                  ))}
                </ul>
              </>
            )}
          </div>
        )}
      </main>
    </div>
  );
}

export default App;